﻿using System;
using System.Collections.Generic;
using System.Text;
using _3Shape.Monarchs.Model;
using System.IO;
using Newtonsoft.Json;

namespace _3Shape.Monarchs.Repository
{
   public class MonarchRepository:IMonarchRepository
    {
        public List<Monarch> FindAll()
        {

           try
            {
                var jsonText = File.ReadAllText("Monarchs.txt");
                return JsonConvert.DeserializeObject<List<Monarch>>(jsonText);
            }

            catch(Exception ex)
            {

                // Write Log

                return null;
            }

        }
    }
}
