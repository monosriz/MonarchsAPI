﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using _3Shape.Monarchs.AppServices;
using _3Shape.Monarchs.AppServices.Messages;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace _3Shape.Monarchs.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MonarchController : ControllerBase
    {

        ApplicationMonarchService _ApplicationMonarchService;

        public MonarchController(ApplicationMonarchService applicationMonarchServic)
        {
            _ApplicationMonarchService = applicationMonarchServic;
        }

        /// <summary>
        /// Total monarchs count
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("TotalMonarchCount")]        
        public IActionResult TotalMonarchCount()
        {
            MonarchGetCountResponse CountResponse= _ApplicationMonarchService.TotalMonarchsCounts();
            return Ok(CountResponse);
        }
        /// <summary>
        /// Get longest monarch ruled and duration
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("LongestMonarchRule")]
        public IActionResult GetLongestMonarchRule()
        {
            LongestMonarchRuledResponse MonarchRuledResponse = _ApplicationMonarchService.LongestMonarchRule();
            return Ok(MonarchRuledResponse);
        }
        /// <summary>
        /// Get longest house ruled and duration
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("LongesHouseRule")]
        public IActionResult GetLongestHouseRule()
        {
            LongestHouseRuledResponse HousrRuledResponse = _ApplicationMonarchService.LongestHouseRule();
            return Ok(HousrRuledResponse);
        }
        /// <summary>
        /// Get most common first name
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("MostCommonFirstName")]
        public IActionResult GetCommonFirstNAme()
        {
            MostCommonFirstNameResponse HousrRuledResponse = _ApplicationMonarchService.MostCommonFirstNAme();
            return Ok(HousrRuledResponse);
        }
    }
}
