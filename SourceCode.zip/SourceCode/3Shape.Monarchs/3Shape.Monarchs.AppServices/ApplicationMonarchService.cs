﻿using System;
using System.Collections.Generic;
using System.Text;
using _3Shape.Monarchs.AppServices.Messages;
using _3Shape.Monarchs.Model;

namespace _3Shape.Monarchs.AppServices
{
    public class ApplicationMonarchService
    {
        private MonarchService _monarchService;
       
        public ApplicationMonarchService(MonarchService monarchService)
        {
            _monarchService = monarchService;
        }

        public MonarchGetCountResponse TotalMonarchsCounts()
        {
            MonarchGetCountResponse CountResponse = new MonarchGetCountResponse();
            try
            {
                CountResponse.Success = true;
                CountResponse.Message = "Successfully Completed";
                _monarchService.GetMonarchsCounts();
                CountResponse.MonarchCount = _monarchService.MonarchCount;
                return CountResponse;
            }

            catch(Exception ex)
            {
                CountResponse.Success = false;
                   
                CountResponse.Message = "Failed - " +ex.Message;
                return CountResponse;
            }
            finally
            {
                CountResponse = null;

            }
        }

        public LongestMonarchRuledResponse LongestMonarchRule()
        {

            LongestMonarchRuledResponse LongestMonarch = new LongestMonarchRuledResponse();

            try
            {
               
            LongestMonarch.Success = true;
            LongestMonarch.Message = "Successfully Completed";
            _monarchService.GetLongestMonarchRule();
            LongestMonarch.LongestMonarchRulerName = _monarchService.LongestMonarchRulerName;
            LongestMonarch.LongestRuleDuration = _monarchService.LongestRuleDuration;
            return LongestMonarch;
            }
            catch (Exception ex)
            {
                LongestMonarch.Success = false;

                LongestMonarch.Message = "Failed - " + ex.Message;
                return LongestMonarch;
            }
            finally
            {
                LongestMonarch = null;

            }
        }

        public LongestHouseRuledResponse LongestHouseRule()
        {
            LongestHouseRuledResponse LongestHouse= new LongestHouseRuledResponse();
            try
            { 
            LongestHouse.Success = true;
            LongestHouse.Message = "Successfully Completed";
            _monarchService.GetLongestHouseRuled();
            LongestHouse.LongestHouseRulerName = _monarchService.LongestHouseRulerName;
            LongestHouse.LongestRuleDuration = _monarchService.LongestRuleDuration;
            return LongestHouse;
            }
            catch (Exception ex)
            {
                LongestHouse.Success = false;

                LongestHouse.Message = "Failed - " + ex.Message;
                return LongestHouse;
            }
            finally
            {
                LongestHouse = null;

            }
        }

        public MostCommonFirstNameResponse MostCommonFirstNAme()
        {
            MostCommonFirstNameResponse CommonNameFirstName = new MostCommonFirstNameResponse();
            try
            {
                CommonNameFirstName.Success = true;
            CommonNameFirstName.Message = "Successfully Completed";
            _monarchService.GetMostCommonFirstName();
            CommonNameFirstName.CommonFirstName = _monarchService.MostCoomonFirstName;
            
            return CommonNameFirstName;
            }
            catch (Exception ex)
            {
                CommonNameFirstName.Success = false;

                CommonNameFirstName.Message = "Failed - " + ex.Message;
                return CommonNameFirstName;
            }
            finally
            {
                CommonNameFirstName = null;

            }
        }
    }
}
