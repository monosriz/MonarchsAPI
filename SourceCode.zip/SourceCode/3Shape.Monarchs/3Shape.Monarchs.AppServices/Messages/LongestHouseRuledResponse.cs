﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.AppServices.Messages
{
    public class LongestHouseRuledResponse : ResponseBase
    {

        public string LongestHouseRulerName { get; set; }
        public int LongestRuleDuration { get; set; }
    }
}
