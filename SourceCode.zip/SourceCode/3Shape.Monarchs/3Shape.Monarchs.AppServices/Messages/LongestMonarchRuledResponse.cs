﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.AppServices.Messages
{
   public class LongestMonarchRuledResponse:ResponseBase
    {
        public string LongestMonarchRulerName { get; set; }
        public int LongestRuleDuration { get; set; }
    }
}
