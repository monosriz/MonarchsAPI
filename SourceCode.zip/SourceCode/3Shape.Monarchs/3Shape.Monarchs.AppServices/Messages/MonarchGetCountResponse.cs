﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.AppServices.Messages
{
   public  class MonarchGetCountResponse:ResponseBase
    {
        public int MonarchCount { get; set; }
    }
}
