﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.AppServices.Messages
{
   public class MostCommonFirstNameResponse : ResponseBase
    {

        public string CommonFirstName { get; set; }

    }
}
