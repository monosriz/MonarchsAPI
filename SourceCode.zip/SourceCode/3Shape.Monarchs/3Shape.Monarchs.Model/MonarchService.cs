﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _3Shape.Monarchs.Model
{
    public class MonarchService
    {
        private IMonarchRepository _monarchRepository;
        private List<Monarch> _monarchs;

        public int MonarchCount
        { get; internal set; }
        public string LongestMonarchRulerName
        { get; internal set; }

        public string LongestHouseRulerName
        { get; internal set; }

        public string MostCoomonFirstName
        { get; internal set; }

        public int LongestRuleDuration
        { get; internal set; }

       
        public MonarchService(IMonarchRepository monarchRepository)
        {
            
            _monarchRepository = monarchRepository;
            _monarchs = _monarchRepository.FindAll();
        }
        /// <summary>
        /// Count Monarchs 
        /// </summary>
        /// <returns></returns>
        public void GetMonarchsCounts()
        {

            try
            {
               
                if (_monarchs != null)
                    MonarchCount= _monarchs.Count;
                else
                    MonarchCount= 0;
            }
            catch (Exception ex)
            {
                //Log Errror Message
                
            }
            
        }
        /// <summary>
        /// Get Longest monarch ruler name and duration
        /// </summary>
        public void GetLongestMonarchRule()
        {

            try
            {
                var _ruledLonegstYear = 0;
                var _monarchName = "";
                var _noofYear = 0;

                if (_monarchs != null)
                {
                    foreach (Monarch element in _monarchs)
                    {


                        if (element.MonarchYear.Contains("-"))
                        {
                            string[] YearArray = element.MonarchYear.Split('-');
                            if (YearArray[1] == "")
                                YearArray[1] = DateTime.Now.Year.ToString();
                            _noofYear = int.Parse(YearArray[1]) - int.Parse(YearArray[0]) + 1;

                        }
                        else
                            _noofYear = 1;

                        if (_ruledLonegstYear < _noofYear)
                        {
                            _ruledLonegstYear = _noofYear;
                            _monarchName = element.MonarchName;
                        }

                    }

                    this.LongestMonarchRulerName = _monarchName;
                    this.LongestRuleDuration = _noofYear;
                }


            }
            catch (Exception ex)
            {
                //Log Errror Message
               
            }
            

        }

        public void GetLongestHouseRuled()
        {

            try
            {
         
                if (_monarchs != null)
                {


                    var NoofYear = 0;
                    Dictionary<string, int> DictMonarch = new Dictionary<string, int>();
                    foreach (Monarch element in _monarchs)
                    {


                        if (element.MonarchYear.Contains("-"))
                        {
                            string[] YearArray = element.MonarchYear.Split('-');
                            if (YearArray[1] == "")
                                YearArray[1] = DateTime.Now.Year.ToString();
                            NoofYear = int.Parse(YearArray[1]) - int.Parse(YearArray[0]) + 1;

                        }
                        else
                            NoofYear = 1;

                        if (DictMonarch.ContainsKey(element.MonarchHouse))
                        {
                            DictMonarch[element.MonarchHouse] = DictMonarch[element.MonarchHouse] + NoofYear;
                        }
                        else
                            DictMonarch.Add(element.MonarchHouse, NoofYear);


                    }



                    LongestHouseRulerName = DictMonarch.FirstOrDefault(x => x.Value == DictMonarch.Values.Max()).Key;
                    LongestRuleDuration = DictMonarch.Values.Max();

                }


            }
            catch (Exception ex)
            {
                //Log Errror Message

            }


        }
        public void GetMostCommonFirstName()
        {

            try
            {

                if (_monarchs != null)
                {


                   
                    Dictionary<string, int> DictMonarch = new Dictionary<string, int>();
                    foreach (Monarch element in _monarchs)
                    {



                        if (DictMonarch.ContainsKey(element.MonarchName.Contains(" ") ? element.MonarchName.Substring(0, element.MonarchName.IndexOf(' ')) : element.MonarchName))
                        {
                            DictMonarch[element.MonarchName.Contains(" ") ? element.MonarchName.Substring(0, element.MonarchName.IndexOf(' ')) : element.MonarchName] = DictMonarch[element.MonarchName.Contains(" ") ? element.MonarchName.Substring(0, element.MonarchName.IndexOf(' ')) : element.MonarchName] + 1;
                        }
                        else
                            DictMonarch.Add(element.MonarchName.Contains(" ") ? element.MonarchName.Substring(0, element.MonarchName.IndexOf(' ')) : element.MonarchName, 1);





                    }



                    MostCoomonFirstName = DictMonarch.FirstOrDefault(x => x.Value == DictMonarch.Values.Max()).Key;
                 

                }


            }
            catch (Exception ex)
            {
                //Log Errror Message

            }


        }
    }
}
