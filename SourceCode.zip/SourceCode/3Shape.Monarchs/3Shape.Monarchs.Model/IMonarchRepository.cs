﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.Model
{
    public interface IMonarchRepository
    {
        List<Monarch> FindAll();
    }
}
