﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3Shape.Monarchs.Model
{
  public  class Monarch
    {
        public Monarch(string id, string nm, string cty,
     string hse, string yrs)
        {
            this.MonarchID = id;
            this.MonarchName = nm;
            this.MonarchCity = cty;
            this.MonarchHouse = hse;
            this.MonarchYear = yrs;

        }
        public string MonarchID
        { get; internal set; }
        public string MonarchName
        { get; internal set; }

        public string MonarchCity
        { get; internal set; }
        public string MonarchHouse
        { get; internal set; }
        public string MonarchYear
        { get; internal set; }


    }


}
