﻿using Microsoft.Extensions.Configuration;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net.Http;

namespace _3Shape.Monarchs.Client
{
    class Program
    {
        static void Main(string[] args)
        {

            using (var client = new HttpClient())
            {

                var builder = new ConfigurationBuilder()
        .SetBasePath(Directory.GetCurrentDirectory())
        .AddJsonFile("appsettings.json");

                var configuration = builder.Build();

                // rest of code...

                client.BaseAddress = new Uri(configuration["APIURL"]);

                //Get Total Monarch Count
                var response = new HttpResponseMessage();
                 response = client.GetAsync("api/Monarch/TotalMonarchCount").Result;
                if (response.IsSuccessStatusCode)
                {

                    dynamic TotalMonarchCount = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    if (TotalMonarchCount.success == true)
                        Console.WriteLine("Total Monarch Count: - "+ TotalMonarchCount.monarchCount);
                }

                //Get Longest Monarch Rule
                response = client.GetAsync("api/Monarch/LongestMonarchRule").Result;
                if (response.IsSuccessStatusCode)
                {

                    dynamic LongestMonarchRuler = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    if (LongestMonarchRuler.success == true)
                        Console.WriteLine("Monarch Ruled the longest: - " + LongestMonarchRuler.longestMonarchRulerName + " - Duration (in Year) "+ LongestMonarchRuler.longestRuleDuration);
                }

                //Get Longest House Rule
                response = client.GetAsync("api/Monarch/LongesHouseRule").Result;
                if (response.IsSuccessStatusCode)
                {

                    dynamic LongestHouseRuler= JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    if (LongestHouseRuler.success == true)
                        Console.WriteLine("House Ruled the longest: - " + LongestHouseRuler.longestHouseRulerName + " - Duration (in Year) " + LongestHouseRuler.longestRuleDuration);
                }

                //Get Most Common First Name
                response = client.GetAsync("api/Monarch/MostCommonFirstName").Result;
                if (response.IsSuccessStatusCode)
                {

                    dynamic MostCommonFirstName = JObject.Parse(response.Content.ReadAsStringAsync().Result);
                    if (MostCommonFirstName.success == true)
                        Console.WriteLine("Most Common First Name: - " + MostCommonFirstName.commonFirstName);
                }
            }

            Console.ReadLine();
        }
    }
}
